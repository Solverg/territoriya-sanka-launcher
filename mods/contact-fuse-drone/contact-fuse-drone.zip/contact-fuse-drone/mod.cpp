name = "Contact Fuse Drone";
author = "universal-modder contributors";
overview = "An AR-2 quadcopter that explodes on its first impact after takeoff.";
actionName = "Offline / controlled-LAN test only";
