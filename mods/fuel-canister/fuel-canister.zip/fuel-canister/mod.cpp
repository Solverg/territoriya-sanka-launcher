name = "Fuel Canister";
author = "universal-modder contributors";
overview = "Одноразовая канистра: подберите её и заправьте транспорт на 15%.";
actionName = "Только одиночная игра / контролируемый LAN";
